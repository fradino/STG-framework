﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_1 : Enemy
{
    public float waveFrequency = 2;

    public float waveWidth = 4;

    public float waveRotY = 45;

    private float x0 = -99999;

    private float birthTime;

    public WeaponType type;

    public WeaponDefinition def;

    // Use this for initialization
    void Start()
    {
        x0 = pos.x;
        birthTime = Time.time;
        type = WeaponType.blaster;
        def = Main.GetWeaponDefinition(type);
        InvokeRepeating("Fire",0.5f,1f);
    }

    public override void Move()
    {
        Vector3 tempPos = pos;
        float age = Time.time - birthTime;
        float theta = Mathf.PI * 2 * age / waveFrequency;
        float sin = Mathf.Sin(theta);
        tempPos.x = x0 + waveWidth * sin;
        pos = tempPos;
        Vector3 rot = new Vector3(0, sin * waveRotY, 0);
        transform.rotation = Quaternion.Euler(rot);
        base.Move();
    }

    public Projectile MakeProjectile()
    {
        Transform PROJECTILE_ANCHOR = GameObject.Find("_Projectile_Anchor").transform;
        GameObject go = Instantiate(def.projectilePrefab);
        go.tag = "ProjectileEnemy";
        go.layer = LayerMask.NameToLayer("ProjectileEnemy");
        go.transform.position = transform.position;
        go.transform.parent = PROJECTILE_ANCHOR;
        Projectile p = go.GetComponent<Projectile>();
        p.type = type;
        return p;
    }

    public void Fire()
    {
        if (!gameObject.activeInHierarchy) return;
        Projectile p;
        p = MakeProjectile();
        p.GetComponent<Rigidbody>().velocity = -Vector3.up * def.velocity;
        p.GetComponent<Renderer>().material.color=Color.cyan;
    }
}